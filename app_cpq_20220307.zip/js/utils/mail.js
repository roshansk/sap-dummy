const nodemailer = require("nodemailer");
const xsenv = require("@sap/xsenv");
let mail = {
	send: function (from, to, subject, body, success, fail) {
		let options = {};
		//Add SMTP
		try {
			options = Object.assign(options, xsenv.getServices({
				mail: {
					"name": "smtp_email_enterprise"
				}
			}));
		} catch (err) {
			console.log("[WARN]", err.message);
		}
		var transporter = nodemailer.createTransport(options.mail);

		var mailOptions = {
			from: from,
			to: to,
			subject: subject,
			html: body
		};
		transporter.sendMail(mailOptions, function (error, info) {
			if (error) {
				console.log(error);
				if (fail) {
					fail(error);
				}
			} else {
				console.log('Email sent:' + info.response);
				if (success) {
					success(info);
				}
			}
		});
	}
};
module.exports = mail;