let config = {
	uaaConfig: {
		uaaCredentials: JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials
	},
	mailTo : 'manohar.singh@non.agilent.com'
};

module.exports = config;