const hdbext = require("@sap/hdbext");
const dbConfig = require("../config/db_config");
const execute = {};

execute.executeQuery = (request) => {
	return new Promise((resolve, reject) => {
		hdbext.createConnection(dbConfig.hanaConfig, (connectionError, client) => {
			if (connectionError) {
				reject(console.error("Error in connection", connectionError));
			} else {
				console.log(`QUERY => ${request}`);
				client.exec(request, (queryError, result) => {
					if (queryError) {
						reject(queryError);
					} else {
						resolve(result);
					}
				});
			}
		});
	});
};

execute.executeProcedure = (request) => {
	return new Promise((resolve, reject) => {
		hdbext.createConnection(dbConfig.hanaConfig, (connectionError, client) => {
			//client.exec(`SET 'REQ_USER'='${request.NTID}'`);
			request.query = request.query ? request.query : {};
			console.log(`Procedure => Schema:${request.schema} , Name : ${request.procedureName}`);

			hdbext.loadProcedure(client, request.schema, request.procedureName, (err, sp) => {
				if (sp) {
					sp(request.query, function (err, parameters, result) {
						if (err) {
							console.error(err);
							reject(err);
						} else {
							console.log("Error", err)
							console.log("result", result);
							console.log("parameters", parameters)
							resolve(result);
						}
					});
				} else {
					var err = `procedure ${request.procedureName} not found`;
					console.error(err);
					reject(err);
				}
			});
		});
	});
};

module.exports = execute;