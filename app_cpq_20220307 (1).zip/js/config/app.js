let config = {
	uaaConfig: {
		uaaCredentials: JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials
	},
	mailTo : 'roshan.kamble@non.agilent.com'
};

module.exports = config;