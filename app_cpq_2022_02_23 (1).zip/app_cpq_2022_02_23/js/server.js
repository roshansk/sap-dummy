"use strict";

var https = require("https");
var server = require("http").createServer();
var express = require('express');
const xsenv = require("@sap/xsenv");
const passport = require("passport");
const bodyParser = require('body-parser');
const http = require('request');
const jwtDecode = require('jwt-decode');

const {
	JWTStrategy
} = require("@sap/xssec");

https.globalAgent.options.ca = xsenv.loadCertificates();

console.log("Initializing Node...");

var hdbext = require("@sap/hdbext");
var app = express();

var BasicStrategy = require('passport-http').BasicStrategy;
passport.use(new BasicStrategy(
	function (username, password, done) {
		var uaaCredentials = JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials;
		let url = `${uaaCredentials.url}/oauth/token`;
		var credentials = {};
		credentials.username = username;
		credentials.password = password;
		credentials.client_id = uaaCredentials.clientid;
		credentials.client_secret = uaaCredentials.clientsecret;
		credentials.grant_type = "password";
		http.post(url, {
			form: credentials
		}, (error, response, body) => {
			if (response && response.statusCode == 200) {
				body = JSON.parse(body);
				let decoded = jwtDecode(body.access_token);
				return done(null, {
					id: decoded.user_name
				});
			} else {
				return done(null, false);
			}
		});
	}
));
var hanaOptions = xsenv.getServices({
	hana: {
		tag: "hana"
	}
});

app.use(passport.initialize());
// app.use(passport.authenticate("basic", {
// 	session: false
// }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
	extended: true
}));

////// ROUTES ///////
var router = require('./router')(app, server);

/////// START SERVER //////
var port = process.env.PORT || 3000;
server.on("request", app);
server.listen(port, function () {
	console.info("HTTP Server: " + server.address().port);
});