sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel"
], function (Controller, JSONModel, ODataModel) {
	"use strict";

	return Controller.extend("UI5_webapp.webapp.controller.Register", {
		
		onInit: function () {
			
			var oDataJSON = new JSONModel();
			var oDataModel = new ODataModel("/service.xsodata",true);
			oDataModel.read("/userModel", {
			success : function(odata,res){
			oDataJSON.setData({"results":odata.results});
			console.log(odata.results);
				}
			});
			this.getView().setModel(oDataJSON,"userModel"); 
			
		},
		
		register : function (){

			this.getView().getModel("oLocal").setProperty("/registerEmailErr","");
			this.getView().getModel("oLocal").setProperty("/registerPasswordErr","");
			this.getView().getModel("oLocal").setProperty("/registerMsg","");

			var credentials = this.getView().getModel("oLocal").getProperty("/register");
			var users = this.getView().getModel("user").getProperty('/users');
			var err = 0;
			
			users.forEach( user => {
				if(credentials.email == user.email){
					this.getView().getModel("oLocal").setProperty("/registerEmailErr",credentials.email+" is already in use!");
					err++;
				}
			});

			if( credentials.password != credentials.password2){
				this.getView().getModel("oLocal").setProperty("/registerPasswordErr","Passwords do not match!");
				err++;
			}

			if(err == 0) {
				this.getView().getModel("oLocal").setProperty("/registerMsg","Registration Successfull!");
				//fetch("https://alinhana25:51042/newUser").then(res => console.log(res));
			}
			else{ 
			this.getView().getModel("oLocal").setProperty("/registerMsg","Registration Failed!");
			}
			console.log("Register Running",err);

		},

		goToLogin : function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("login");
		},

		
	});
});