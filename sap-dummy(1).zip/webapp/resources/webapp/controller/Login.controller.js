sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel"
], function (Controller, JSONModel, ODataModel) {
	"use strict";

	return Controller.extend("UI5_webapp.webapp.controller.Login", {
		
		onInit: function () {
			
			var oDataJSON = new JSONModel();
			var oDataModel = new ODataModel("/service.xsodata",true);
			oDataModel.read("/userModel", {
			success : function(odata,res){
			oDataJSON.setData({"results":odata.results});
			console.log(odata.results);
				}
			});
			this.getView().setModel(oDataJSON,"userModel"); 
			
		},
		
		login: function() {
			var credentials = this.getView().getModel("oLocal").getProperty("/login");
			var users = this.getView().getModel("user").getProperty('/users');
			console.log(credentials,users);
			var hasLoggedIn = false;
			var loggedInUser = {};
			
			users.forEach( user => {
				if ( credentials.email == user.email && credentials.password == user.password){
					hasLoggedIn = true;
					loggedInUser = user;
				}
			} );
			
			if(hasLoggedIn){
				this.getView().getModel("oLocal").setProperty("/loginMsg","Login Successful User - "+loggedInUser.name);
				this.getView().getModel("oLocal").setProperty("/userInSession",loggedInUser);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("home");
			}
			else{
				this.getView().getModel("oLocal").setProperty("/loginMsg","Login Failed!");
			}
		},

	
		goToRegister : function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("register");
		},
		
	});
});