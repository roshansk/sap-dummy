sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/ColumnListItem',
	'sap/m/Input',
	'sap/m/Text',
	"sap/m/ObjectIdentifier",
	"sap/m/MessageToast"
], function (Controller, Fragment, JSONModel, ODataModel, ColumnListItem, Input, Text, ObjectIdentifier) {
	"use strict";

	return Controller.extend("UI5_webapp.webapp.controller.Index", {
		
		onInit: function () {
			// Odata service
			var oDataJSON = new JSONModel({"results":[]});
			this.getView().setModel(oDataJSON,"userJSONModel");
			
			var oDataModel = new ODataModel("/service.xsodata",{
				defaultBindingMode:sap.ui.model.BindingMode.TwoWay,                                         
				defaultUpdateMethod:sap.ui.model.odata.UpdateMethod.Put,
				disableHeadRequestForToken:true,
				json:true, 
				useBatch:false,
			});
			console.log("ODataModel",oDataModel);
			oDataModel.read("/userModel", {
			success : function(odata,res){
				oDataJSON.setData({"results":odata.results});
			},
			error : function (err) {
				console.log(err);
			}
				
			});
			this.getView().setModel(oDataModel,"userODataModel");
			
			var oTable = this.getView().byId("userSmartTable");
			var oSmartFilter = this.getView().byId("smartFilterBar");
			oTable.setModel(oDataModel);
			oSmartFilter.setModel(oDataModel);
			oTable.setEntitySet("userModel");
			oTable.setInitiallyVisibleFields("u_id,u_name,u_email,u_role");
			
			
			//Upload Table logic
			
			this.userTemplateModel = this.getView().getModel("userTemplateModel");
			this.editableUserTemplate =  new ColumnListItem({
				cells: [
					new Input({
						value: "{userTemplateModel>u_id}",
					}), 
					new Input({
						value: "{userTemplateModel>u_name}"
					}), 
					new Input({
						value: "{userTemplateModel>u_email}"
					}), 
					new Input({
						value: "{userTemplateModel>u_role}"
					}), 
					new Input({
						value: "{userTemplateModel>u_password}"
					})
					
				]
			});
			
			this.readOnlyUserTemplate =  new ColumnListItem({
				cells: [
					new ObjectIdentifier({
						title: "{userTemplateModel>u_id}",
					}), 
					new Text({
						text: "{userTemplateModel>u_name}"
					}), 
					new Text({
						text: "{userTemplateModel>u_email}"
					}), 
					new Text({
						text: "{userTemplateModel>u_role}"
					}), 
					new Text({
						text: "{userTemplateModel>u_password}"
					})
					
				]
			});
		},
		
		refreshModels : function(){
			var oDataModel = this.getView().getModel("userODataModel");
			var oDataJSON = this.getView().getModel("userJSONModel");
			oDataModel.read("/userModel", {
			success : function(odata,res){
			oDataJSON.setProperty("/results",odata.results);
			console.log(odata.results,res);
				},
			});
		},
		
	
		saveChanges : function(){
			
			var oModel = this.getView().getModel("userODataModel");
			oModel.setHeaders({
				"content-type": "application/json;charset=utf-8"
			});
			var params = {
				success: function(oData){
					console.log("Commit Successful",oData)
				},
				error:function(err){
					console.log("Commit Failed",err);
				}
			}
			oModel.submitChanges(params);
			this.refreshModels();
		},
		
		deleteUserRecord : function (oEvent){
			var oTable = this.getView().byId("userSmartTable").getTable();
			var oModel = this.getView().getModel("userODataModel");
			var indices = oTable.getSelectedIndices();
			var mMsgs = {
				success : [],
				error : []
			}
			var batchDelete = [];
			for( var i = 0; i<indices.length; i++){
				var context = oTable.getContextByIndex(indices[i]);
				console.log(context.sPath);
				oModel.remove(context.sPath,{
					success : function(oData,res){
						mMsgs.success.push({
							data:oData,
							msg : res,
						})
					},
					error : function(err) {
						mMsgs.error.push({
							msg : err,
						})
					}
				});
			}
			console.log(mMsgs);
			this.refreshModels();
		},
		
		// Initiate Dialog
		initiateDialog : function(dialogId,filename){
			var viewPath = "UI5_webapp.webapp.view.";
			var oView = this.getView();
			if(!this.byId(dialogId)){
				Fragment.load({
					id:oView.getId(),
					name:viewPath+filename,
					controller : this
				}).then( function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			}
			else{
				this.byId(dialogId).open();
			}
			
		},
		
		//close Dialog
		closeDialog : function(dialogId){
			this.byId(dialogId).close();
		},
		

		//Upload event handler
		
		handleUploadEvent : function(){
			this.initiateDialog("uploadDetailsDialog", "UploadDetails");
		},
		
		//Close upload dialog
		
		closeUploadDialog : function (oEvent){
			this.closeDialog("uploadDetailsDialog");
		},
		
	
		rebindUpdateTable: function(oTemplate, sKeyboardMode) {
			
			this.oUpdateTable.bindItems({
				path: "userTemplateModel>/users",
				template: oTemplate,
				templateShareable: true,
				key: "u_id"
			}).setKeyboardMode(sKeyboardMode);
		},
		
		editUpdateTable : function () {
			if(!this.oUpdateTable){
				this.oUpdateTable = this.getView().byId("userUpdateTable");
			}
			this.getView().byId("editBtn").setVisible(false);
			this.getView().byId("saveBtn").setVisible(true);
			this.getView().byId("cancelBtn").setVisible(true);
			this.getView().byId("addRowBtn").setVisible(true);
			this.rebindUpdateTable(this.editableUserTemplate, "Edit");
		},
		
		cancelUpdateTable : function () {
			this.getView().byId("editBtn").setVisible(true);
			this.getView().byId("saveBtn").setVisible(false);
			this.getView().byId("cancelBtn").setVisible(false);
			this.getView().byId("addRowBtn").setVisible(false);
			this.rebindUpdateTable(this.readOnlyUserTemplate, "Navigation");
		}
	});
});